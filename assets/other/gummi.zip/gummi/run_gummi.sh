#!/bin/bash

export DISPLAY=:0
gummi $1
